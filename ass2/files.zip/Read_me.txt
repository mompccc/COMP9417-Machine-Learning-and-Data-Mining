Please use python3 or python3.6 to run programs

To do classification of file "ionosphere.arff", please run the py file "classify.py". Just run the program and you don't need to set any parameters. The output will be the results of classifying and cross-validation from k=1 to k=29.

To do prediction of file "autos.arff", please run the py file "predict.py". Just run the program and you don't need to set any parameters. The output will be the average error rate and root-mean-square error from k=1 to k=29.